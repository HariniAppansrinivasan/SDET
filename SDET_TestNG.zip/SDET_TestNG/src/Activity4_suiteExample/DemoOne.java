package Activity4_suiteExample;

import org.testng.annotations.Test;

public class DemoOne {
	  @Test
	  public void tc1() {
		  System.out.println("I'm in first test case from demoOne Class");
	  }
	  
	  @Test
	  public void tc2() {
		  System.out.println("I'm in second test case from demoOne Class");
	  }
}
