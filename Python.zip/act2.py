number = int(input ("Enter a number"))
result = number % 2
if result > 0:
    print ("Number entered is odd")
else:
    print ("Number entered is even")