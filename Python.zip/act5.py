y=int(input("Enter a number: "))
for x in range(1,11):
    z=x*y
    #print (str(y)+" * "+str(x)+" = "+ str(z))
    print (y," * ",x," = ", z)
