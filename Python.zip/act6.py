for x in range(1,10):
    z=""
    for y in range (0,x):
        z=z+str(x)
    print (z)


"""
for i in range(10):
    print(str(i) * i)
"""